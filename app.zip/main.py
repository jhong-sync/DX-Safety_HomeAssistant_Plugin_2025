def main():
    print("Hello from dx-safety-homeassistant-plugin-2025!")


if __name__ == "__main__":
    main()
